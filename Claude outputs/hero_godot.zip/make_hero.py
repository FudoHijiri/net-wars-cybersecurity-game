"""NET WARS hero persona 'Guardian': 128x128 full body, 6-frame idle, Sweetie 16 only. Faces RIGHT. Feet row = 122."""
import math, os, sys
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fig import *
from make_enemies_v2 import ph, ell, rect, poly, multi, N

R_SCARF = [SKY, CYAN, WHITE]
PROMPT = ['#.......', '.#......', '..#.....', '.#......', '#...####']
CHECK = ['.......##', '......##.', '#....##..', '##..##...', '.####....', '..##.....']


def hero(f):
    g = Fig()
    dy = 1 if ph(f) > 0.3 else 0
    sw = lambda k, o=0.0: math.sin(2 * math.pi * (k - f / N + o))
    # ---- cape (back)
    w = round(ph(f, 1, 0.2) * 3)
    cape = [(54, 50 + dy), (64, 52 + dy), (64, 100), (48, 110), (34 + w, 104), (24 + w * 2, 90), (34, 66)]
    g.part(poly(cape), R_NAVY, sigma=5, vgrad=0.1)
    d = g.d()
    d.line([(46, 70), (40 + w, 102)], fill=(*INK, 255)); d.line([(54, 66), (50, 106)], fill=(*INK, 255))
    # ---- sword (left hand, blade up)
    g.part(poly([(32, 80), (41, 80), (41, 28), (36.5, 14), (32, 28)]), [BLUE, CYAN, WHITE], sigma=2.2, light=(-0.9, -0.1))
    d = g.d()
    d.line([(37, 22), (37, 78)], fill=(*WHITE, 255))
    sy = 28 + (f * 9) % 50
    d.line([(34, sy), (39, sy)], fill=(*WHITE, 255)); d.line([(34, sy + 1), (39, sy + 1)], fill=(*CYAN, 255))
    for i, (x, y) in enumerate(((26, 40), (46, 52), (24, 62), (47, 30))):
        yy = y - ((f + i * 2) % N) * 2
        if (f + i) % 2 == 0:
            g.px(x, yy, CYAN)
    g.part(rect(26, 80, 47, 84, 1), R_GOLD, sigma=1.4)
    g.part(rect(34, 84, 39, 98), R_DARK, sigma=1.2)
    g.part(ell(33, 98, 40, 105), R_GOLD, sigma=2)
    # ---- scarf tail (flutters in front of the blade)
    pts = []
    for k in range(12):
        t = k / 11.0
        pts.append((60 - k * 4.4, 52 + dy + k * 1.0 + sw(t * 1.2) * 5 * (0.25 + t)))
    def scarf(dd):
        for k, (x, y) in enumerate(pts):
            r = 5.2 - 2.6 * k / 11
            dd.ellipse([x - r, y - r, x + r, y + r], fill=255)
    g.part(scarf, R_HOT, sigma=1.8)
    ex, ey = pts[-1]
    g.part(poly([(ex + 1, ey - 3), (ex - 8, ey - 7), (ex - 4, ey - 1), (ex - 9, ey + 6), (ex + 1, ey + 3)]), R_HOT, sigma=1.3)
    # ---- legs and boots
    g.part(multi(rect(50, 90, 62, 114), rect(68, 90, 82, 114)), R_NAVY, sigma=2.4)
    g.part(multi(rect(46, 108, 68, 122, 3), rect(64, 108, 90, 122, 4)), [INK, DARK, SLATE], sigma=2.2)
    g.part(multi(rect(47, 107, 63, 110), rect(66, 107, 84, 110)), R_GOLD, sigma=1.0)
    # ---- torso
    g.part(rect(48, 50 + dy, 86, 98 + dy, 8), [NAVY, BLUE, SKY], sigma=6, vgrad=0.1)
    g.part(rect(55, 54 + dy, 80, 80 + dy, 4), [BLUE, SKY, CYAN], sigma=3, outline=NAVY, gain=0.8)
    g.bitmap(PROMPT, 61, 62 + dy, {'#': INK})
    g.bitmap(PROMPT, 61, 61 + dy, {'#': YELLOW})
    g.part(rect(48, 90 + dy, 86, 96 + dy), R_GOLD, sigma=1.2)
    g.part(rect(63, 89 + dy, 71, 97 + dy, 1), [ORANGE, YELLOW, WHITE], sigma=1.6)
    # ---- left arm (holds sword) + gauntlet
    g.part(thick_line([(50, 58 + dy), (42, 72 + dy), (38, 86 + dy)], 11), R_NAVY, sigma=2.4)
    g.part(ell(32, 81 + dy, 44, 93 + dy), R_STEEL, sigma=2.4)
    g.part(ell(40, 46 + dy, 58, 64 + dy), R_ICE, sigma=3.2)
    g.d().arc([40, 46 + dy, 58, 64 + dy], 180, 300, fill=(*YELLOW, 255), width=2)
    g.part(ell(41, 47 + dy, 57, 63 + dy), [YELLOW, YELLOW, YELLOW], sigma=1, outline=None) if False else None
    # ---- head
    g.part(poly([(52, 18 + dy), (54, 3 + dy), (64, 12 + dy)]), R_ICE, sigma=2)
    g.part(poly([(72, 11 + dy), (80, 2 + dy), (86, 20 + dy)]), R_ICE, sigma=2)
    g.part(ell(46, 6 + dy, 92, 52 + dy), R_ICE, sigma=10, light=(-0.55, -0.85))
    g.part(poly([(58, 24 + dy), (92, 22 + dy), (92, 40 + dy), (68, 44 + dy), (56, 36 + dy)]), [INK, INK, DARK], sigma=2, outline=NAVY, gain=0.5)
    d = g.d()
    for ex0, ew in ((64, 9), (79, 10)):
        if f == 4:
            d.line([(ex0, 32 + dy), (ex0 + ew, 32 + dy)], fill=(*CYAN, 255))
        else:
            d.polygon([(ex0, 28 + dy), (ex0 + ew, 28 + dy + 1), (ex0 + ew, 34 + dy), (ex0 + 2, 34 + dy)], fill=(*CYAN, 255))
            d.rectangle([ex0 + ew - 4, 29 + dy, ex0 + ew - 2, 31 + dy], fill=(*WHITE, 255))
    d.line([(62, 38 + dy), (82, 40 + dy)], fill=(*DARK, 255))
    g.px(52, 20 + dy, WHITE); g.px(53, 19 + dy, WHITE); g.px(54, 18 + dy, WHITE)
    # ---- neck scarf ring
    g.part(ell(56, 46 + dy, 84, 58 + dy), R_HOT, sigma=3)
    # ---- right arm + holo shield
    g.part(thick_line([(82, 58 + dy), (94, 68 + dy), (96, 84 + dy)], 11), R_NAVY, sigma=2.4)
    g.part(ell(76, 46 + dy, 94, 64 + dy), R_ICE, sigma=3.2)
    g.d().arc([76, 46 + dy, 94, 64 + dy], 200, 330, fill=(*YELLOW, 255), width=2)
    sh = [(94, 48 + dy), (122, 54 + dy), (120, 86), (107, 110), (95, 88)]
    pulse = f / N
    shm = g.part(poly(sh), [BLUE, SKY, CYAN], sigma=6, light=(-0.5, -0.8), gain=0.7, outline=INK)
    d = g.d()
    d.polygon(sh, outline=(*YELLOW, 255), width=2)
    a = np.array(g.im)
    inner = shm.copy()
    for (x0, y0, x1, y1) in ((100, 60, 116, 60), (98, 72, 118, 72), (100, 84, 116, 84), (104, 94, 112, 94)):
        pass
    ys = 50 + (f * 12) % 64
    band = shm & (np.abs(YY - ys) <= 1) & (XX > 98) & (XX < 119)
    a[band, :3] = np.array(WHITE)
    g.im.paste(Image.fromarray(a), (0, 0))
    d = g.d()
    for (x, y) in ((104, 62), (112, 66), (104, 76), (112, 80), (108, 90)):
        d.point((x, y + 0), fill=(*CYAN, 255))
    g.bitmap(CHECK, 103, 66 + (1 if dy else 0), {'#': INK})
    g.bitmap(CHECK, 103, 65 + (1 if dy else 0), {'#': WHITE})
    g.part(ell(89, 83 + dy, 101, 95 + dy), R_STEEL, sigma=2.4)
    return g.finish()


if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'hero_out'
    os.makedirs(out, exist_ok=True)
    frs = [hero(f) for f in range(N)]
    for i, fr in enumerate(frs):
        check_palette(fr, f'hero{i}')
    sheet = Image.new('RGBA', (S * N, S), (0, 0, 0, 0))
    for i, fr in enumerate(frs):
        sheet.alpha_composite(fr, (i * S, 0))
    sheet.save(os.path.join(out, 'hero_idle_sheet.png'))
    pv = Image.new('RGBA', (S * 3 + 8, S * 2 + 6), (*INK, 255))
    for i, fr in enumerate(frs):
        pv.alpha_composite(fr, (2 + (i % 3) * (S + 2), 2 + (i // 3) * (S + 2)))
    pv.resize((pv.width * 2, pv.height * 2), Image.NEAREST).save(os.path.join(out, 'hero_preview.png'))
    print('ok')
