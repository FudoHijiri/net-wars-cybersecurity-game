"""Tiny shaded-pixel-art engine (Sweetie 16 only).
Each part is a silhouette (drawn into a mask) that is lit from the top-left with a
palette ramp: the blurred mask acts as a height-field, its slope gives the light, and
ordered dithering softens the band edges.  Parts are drawn back to front."""
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter

S = 128
GROUND = 122
INK, DARK, SLATE, SILVER, WHITE = (26, 28, 44), (51, 60, 87), (86, 108, 134), (148, 176, 194), (244, 244, 244)
NAVY, BLUE, SKY, CYAN, TEAL = (41, 54, 111), (59, 93, 201), (65, 166, 246), (115, 239, 247), (37, 113, 121)
RED, ORANGE, YELLOW, LIME, GREEN, PLUM = (177, 62, 83), (239, 125, 87), (255, 205, 117), (167, 240, 112), (56, 183, 100), (93, 39, 93)
PALETTE = {INK, DARK, SLATE, SILVER, WHITE, NAVY, BLUE, SKY, CYAN, TEAL, RED, ORANGE, YELLOW, LIME, GREEN, PLUM}

# colour ramps, dark -> light
R_PLUM = [INK, PLUM, RED]
R_RED = [PLUM, RED, ORANGE]
R_HOT = [RED, ORANGE, YELLOW]
R_GOLD = [RED, ORANGE, YELLOW, WHITE]
R_BLUE = [NAVY, BLUE, SKY]
R_ICE = [BLUE, SKY, CYAN, WHITE]
R_GREEN = [TEAL, GREEN, LIME]
R_STEEL = [DARK, SLATE, SILVER, WHITE]
R_DARK = [INK, DARK, SLATE]
R_WHITE = [SLATE, SILVER, WHITE]
R_NAVY = [INK, NAVY, BLUE]
R_TEAL = [INK, TEAL, GREEN]

B8 = np.array([[0, 32, 8, 40, 2, 34, 10, 42], [48, 16, 56, 24, 50, 18, 58, 26], [12, 44, 4, 36, 14, 46, 6, 38],
               [60, 28, 52, 20, 62, 30, 54, 22], [3, 35, 11, 43, 1, 33, 9, 41], [51, 19, 59, 27, 49, 17, 57, 25],
               [15, 47, 7, 39, 13, 45, 5, 37], [63, 31, 55, 23, 61, 29, 53, 21]]) / 64.0
BAYER = np.tile(B8, (S // 8, S // 8))
YY, XX = np.mgrid[0:S, 0:S]


class Fig:
    def __init__(self):
        self.im = Image.new('RGBA', (S, S), (0, 0, 0, 0))

    # ---- direct drawing on top (flat colours)
    def d(self):
        return ImageDraw.Draw(self.im)

    def px(self, x, y, c):
        if 0 <= x < S and 0 <= y < S:
            self.im.putpixel((int(x), int(y)), (*c, 255))

    def bitmap(self, rows, x0, y0, cmap):
        for y, r in enumerate(rows):
            for x, ch in enumerate(r):
                if ch in cmap:
                    self.px(x0 + x, y0 + y, cmap[ch])

    # ---- shaded parts
    def mask(self, fn):
        m = Image.new('L', (S, S), 0)
        fn(ImageDraw.Draw(m))
        return np.array(m) > 0

    def part(self, fn, ramp, sigma=3.0, light=(-0.6, -0.8), gain=1.0, bias=0.0, vgrad=0.0, dw=0.35, outline=INK):
        m = self.mask(fn) if callable(fn) else fn
        if not m.any():
            return m
        a = np.array(self.im)
        if outline is not None:
            g = m.copy()
            g[1:, :] |= m[:-1, :]; g[:-1, :] |= m[1:, :]; g[:, 1:] |= m[:, :-1]; g[:, :-1] |= m[:, 1:]
            a[g & ~m] = (*outline, 255)
        hm = gaussian_filter(m.astype(float), sigma, mode='constant')
        gy, gx = np.gradient(hm)
        L = np.array(light) / np.hypot(*light)
        s = -(gx * L[0] + gy * L[1])
        sc = np.percentile(np.abs(s[m]), 95) + 1e-9
        v = 0.5 + 0.5 * gain * np.clip(s / sc, -1, 1) + bias
        if vgrad:
            ys = YY[m]
            y0, y1 = ys.min(), ys.max() + 1
            v = v + vgrad * (0.5 - (YY - y0) / float(y1 - y0))
        n = len(ramp)
        x = v * (n - 1) + 0.5 + (BAYER - 0.5) * dw
        idx = np.clip(np.floor(x), 0, n - 1).astype(int)
        pal = np.array(ramp, dtype=np.uint8)
        a[m, :3] = pal[idx[m]]
        a[m, 3] = 255
        self.im.paste(Image.fromarray(a), (0, 0))
        return m

    def finish(self, outer=INK):
        a = np.array(self.im)
        al = a[..., 3] > 0
        g = al.copy()
        g[1:, :] |= al[:-1, :]; g[:-1, :] |= al[1:, :]; g[:, 1:] |= al[:, :-1]; g[:, :-1] |= al[:, 1:]
        a[g & ~al] = (*outer, 255)
        return Image.fromarray(a)

    def lut(self, mapping, region):
        a = np.array(self.im)
        for src, dst in mapping.items():
            m = region & np.all(a[..., :3] == np.array(src), axis=-1) & (a[..., 3] == 255)
            a[m, :3] = dst
        self.im.paste(Image.fromarray(a), (0, 0))


def check_palette(im, label=''):
    a = np.array(im)
    cols = {tuple(c[:3]) for c in a.reshape(-1, 4) if c[3]}
    assert cols <= PALETTE, (label, cols - PALETTE)
    assert set(np.unique(a[..., 3])) <= {0, 255}, label


def thick_line(pts, w):
    """returns a fn(d) that draws a thick polyline with round joints into a mask"""
    def fn(d):
        d.line(pts, fill=255, width=w, joint='curve')
        for x, y in pts:
            d.ellipse([x - w / 2, y - w / 2, x + w / 2, y + w / 2], fill=255)
    return fn
