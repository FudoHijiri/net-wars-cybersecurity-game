"""NET WARS enemies v2: 8 threats, 128x128 full-body sprites, 6-frame idle, Sweetie 16 only.
Facing LEFT (toward Joshua). Feet / ground row = 122."""
import math, os, random, sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fig import *

N = 6
STAR = ['..#..', '#.#.#', '.###.', '#.#.#', '..#..']
DOLLAR = ['..#..', '.####', '#.#..', '.###.', '..#.#', '####.', '..#..']


def ph(f, k=1.0, off=0.0):
    return math.sin(2 * math.pi * (f / N * k + off))


def ell(x0, y0, x1, y1):
    return lambda d: d.ellipse([x0, y0, x1, y1], fill=255)


def rect(x0, y0, x1, y1, r=0):
    if r:
        return lambda d: d.rounded_rectangle([x0, y0, x1, y1], r, fill=255)
    return lambda d: d.rectangle([x0, y0, x1, y1], fill=255)


def poly(pts):
    return lambda d: d.polygon(pts, fill=255)


def multi(*fns):
    def fn(d):
        for f_ in fns:
            f_(d)
    return fn


# =============================================================== 1. CREDENTIAL ABUSE - The Impersonator
def e_credential(f):
    g = Fig()
    sw = ph(f, 1, 0.25)
    dy = 1 if ph(f) > 0.3 else 0
    tail = [(76, 50 + dy), (98 + round(sw * 3), 72), (112 + round(sw * 5), 100), (108 + round(sw * 4), 118), (86, 112)]
    g.part(poly(tail), R_PLUM, sigma=4)
    hem = []
    for i, x in enumerate(range(106, 31, -9)):
        hem.append((x, 115 + ((i + f) % 2) * 2 - (1 if i % 3 == 0 else 0)))
        hem.append((x - 4, 109 + ((i + f + 1) % 2) * 2))
    g.part(multi(rect(44, 110, 62, 122, 3), rect(72, 110, 94, 122, 3)), [INK, DARK, SLATE], sigma=1.8)
    cloak = [(52, 46 + dy), (76, 46 + dy), (88, 64), (98, 92), (106, 117)] + hem + [(30, 117), (34, 92), (44, 64)]
    g.part(poly(cloak), R_PLUM, sigma=7, vgrad=0.1)
    d = g.d()
    for x0, x1 in ((58, 54), (66, 66), (76, 82), (88, 96)):
        d.line([(x0, 70 + dy), (x1, 110)], fill=(*INK, 255))
    d.line([(50, 74), (44, 110)], fill=(*RED, 255))
    g.part(rect(48, 80 + dy, 84, 84 + dy), R_DARK, sigma=1.2)
    for i, (c, x) in enumerate(((WHITE, 46), (YELLOW, 55), (CYAN, 64))):
        s = round(ph(f, 1, 0.1 * i + 0.3) * 1.5)
        d = g.d()
        d.line([(x + 4, 84 + dy), (x + 4 + s, 90 + dy)], fill=(*SILVER, 255))
        d.rectangle([x + s, 90 + dy, x + 8 + s, 102 + dy], fill=(*c, 255), outline=(*INK, 255))
        d.rectangle([x + 2 + s, 92 + dy, x + 5 + s, 96 + dy], fill=(*(SLATE if c != CYAN else BLUE), 255))
    g.part(poly([(78, 20 + dy), (100 + round(sw * 2), 14 + dy), (86, 46 + dy)]), R_PLUM, sigma=3)
    g.part(ell(42, 10 + dy, 86, 56 + dy), R_PLUM, sigma=8, light=(-0.5, -0.9))
    g.part(ell(40, 23 + dy, 72, 58 + dy), [INK, INK, DARK], sigma=4, outline=None)
    g.part(ell(44, 26 + dy, 68, 54 + dy), R_WHITE, sigma=6, light=(-0.7, -0.6))
    d = g.d()
    for ex in (47, 58):
        if f == 3:
            d.line([(ex, 37 + dy), (ex + 6, 37 + dy)], fill=(*INK, 255))
        else:
            d.polygon([(ex, 34 + dy), (ex + 6, 36 + dy), (ex + 6, 39 + dy), (ex + 1, 38 + dy)], fill=(*YELLOW, 255))
            d.point((ex + 4, 37 + dy), fill=(*WHITE, 255))
    for x in range(47, 65):
        g.px(x, 46 + dy + round(3 * math.sin(math.pi * (x - 47) / 17)), INK)
    g.px(46, 45 + dy, INK); g.px(65, 45 + dy, INK)
    kx = 22 + round(ph(f, 1, 0.1))
    g.part(rect(kx, 40 + dy, kx + 4, 106 + dy), R_GOLD, sigma=1.4, light=(-0.9, -0.2))
    g.part(lambda d: (d.ellipse([kx - 14, 12 + dy, kx + 18, 44 + dy], fill=255), d.ellipse([kx - 7, 19 + dy, kx + 11, 37 + dy], fill=0)), R_GOLD, sigma=2.2)
    g.part(multi(rect(kx + 5, 94 + dy, kx + 17, 100 + dy), rect(kx + 5, 103 + dy, kx + 13, 108 + dy), rect(kx + 5, 85 + dy, kx + 11, 90 + dy)), R_GOLD, sigma=1.0)
    g.part(thick_line([(56, 62 + dy), (46, 74 + dy), (kx + 6, 84 + dy)], 12), R_PLUM, sigma=3)
    g.part(ell(kx - 5, 77 + dy, kx + 10, 91 + dy), R_DARK, sigma=2.5)
    if f in (1, 2):
        for dx, dyy in ((-9, 0), (-8, -1), (-8, 1), (-10, -1)):
            g.px(kx + dx, 22 + dy + dyy, WHITE)
    for i, (x, y) in enumerate(((100, 34), (112, 54), (104, 72))):
        yy = max(6, y - round(ph(f, 1, 0.2 * i) * 2) - ((f + i * 2) % N))
        g.bitmap(STAR, x, yy, {'#': CYAN if i != 1 else YELLOW})
    return g.finish()


# =============================================================== 2. MALWARE - Glitch Bug
def e_malware(f):
    g = Fig()
    p = ph(f)
    cx, cy = 64, 62 - round(p)
    rx, ry = 34 + round(p), 30 + round(p * 0.6)
    for i, (hx, kx_, fx) in enumerate(((-26, -46, -52), (-16, -34, -36), (-5, -20, -20))):
        for sgn in (-1, 1):
            lift = 4 if (i + f + (1 if sgn > 0 else 0)) % 2 else 0
            hip = (cx + sgn * -hx * -1 if False else cx + sgn * abs(hx), cy + 22)
            knee = (cx + sgn * abs(kx_), cy + 34 - i * 2)
            foot = (cx + sgn * abs(fx) + sgn * (2 if lift else 0), 121 - lift)
            g.part(thick_line([hip, knee, foot], 6), [INK, TEAL, GREEN], sigma=1.8)
            g.part(ell(foot[0] - 4, foot[1] - 2, foot[0] + 4, foot[1] + 2), R_GREEN, sigma=1.2)
    for a in (-170, -140, -110, -80, -50, -20, 20, 160):
        ar = math.radians(a + round(p * 4))
        bx, by = cx + rx * math.cos(ar), cy + ry * math.sin(ar)
        nx, ny = math.cos(ar), math.sin(ar)
        tx, ty = bx + nx * 14, by + ny * 14
        g.part(thick_line([(bx, by), (tx, ty)], 4), R_GREEN, sigma=1.2)
        g.part(ell(tx - 5, ty - 5, tx + 5, ty + 5), R_HOT, sigma=2.2)
        g.px(round(tx) - 2, round(ty) - 2, WHITE)
    g.part(ell(cx - rx, cy - ry, cx + rx, cy + ry), R_GREEN, sigma=11, light=(-0.5, -0.8))
    d = g.d()
    for (ox, oy, r) in ((-22, -18, 5), (22, -12, 4), (8, -24, 3), (-26, 4, 3), (28, 8, 4)):
        d.ellipse([cx + ox - r, cy + oy - r, cx + ox + r, cy + oy + r], fill=(*TEAL, 255))
        d.point((cx + ox - 1, cy + oy - 1), fill=(*GREEN, 255))
    for ox, oy, r, pw in ((-14, -8, 10, -3), (14, -10, 8, -2)):
        d.ellipse([cx + ox - r, cy + oy - r, cx + ox + r, cy + oy + r], fill=(*WHITE, 255), outline=(*INK, 255))
        px = cx + ox + pw + (2 if f == 2 else 0)
        d.ellipse([px - 4, cy + oy - 4, px + 4, cy + oy + 4], fill=(*RED, 255))
        d.rectangle([px - 1, cy + oy - 2, px + 1, cy + oy + 2], fill=(*INK, 255))
        d.point((px - 3, cy + oy - 3), fill=(*WHITE, 255))
    d.line([(cx - 28, cy - 24), (cx - 4, cy - 12)], fill=(*INK, 255), width=3)
    d.line([(cx + 26, cy - 24), (cx + 4, cy - 14)], fill=(*INK, 255), width=3)
    mo = 1 + abs(round(p * 2))
    d.ellipse([cx - 20, cy + 8, cx + 20, cy + 26 + mo], fill=(*INK, 255))
    d.ellipse([cx - 10, cy + 18 + mo // 2, cx + 10, cy + 27 + mo], fill=(*RED, 255))
    for i in range(7):
        x = cx - 17 + i * 5
        d.polygon([(x, cy + 11 - (abs(i - 3) // 2)), (x + 4, cy + 11 - (abs(i - 3) // 2)), (x + 2, cy + 16 - (abs(i - 3) // 2))], fill=(*WHITE, 255))
    for i, (x, y, c) in enumerate(((12, 30, LIME), (112, 44, TEAL), (18, 70, TEAL), (108, 78, LIME), (30, 14, GREEN))):
        yy = (y + f * 3 + i * 5) % 90 + 6
        d.rectangle([x, yy, x + 2, yy + 2], fill=(*c, 255))
    if f in (2, 3):
        g.im = Image.fromarray(np.roll(np.array(g.im), 4 if f == 2 else -3, axis=1) * 0 + np.array(g.im)) if False else g.im
        a = np.array(g.im); a[44:50] = np.roll(a[44:50], 5 if f == 2 else -4, axis=1); a[78:82] = np.roll(a[78:82], -4 if f == 2 else 3, axis=1)
        g.im = Image.fromarray(a)
    return g.finish()


# =============================================================== 3. RANSOMWARE - Lockjaw
def e_ransom(f):
    g = Fig()
    p = ph(f)
    dy = 1 if p > 0.3 else 0
    lift = [0, 1, 3, 4, 3, 1][f]
    g.part(multi(rect(40, 102, 58, 122, 3), rect(70, 102, 88, 122, 3)), R_STEEL, sigma=2.4)
    g.part(multi(rect(38, 106, 60, 111), rect(68, 106, 90, 111)), R_RED, sigma=1.5)
    g.part(lambda d: d.rounded_rectangle([42, 8 - lift + dy, 86, 66 + dy], radius=20, outline=255, width=11), R_STEEL, sigma=2.2)
    d = g.d()
    for (xx, yy) in ((50, 20), (51, 18), (52, 17)):
        g.px(xx, yy - lift + dy, WHITE)
    for sgn, x0 in ((-1, 30), (1, 98)):
        pts = []
        for i in range(6):
            t = i / 5.0
            x = x0 + sgn * (14 * t) + sgn * round(ph(f, 1, 0.12 * i) * 2) * t
            y = 70 + 28 * t + dy
            pts.append((x, y))
            d = g.d()
            if i % 2:
                d.rectangle([x - 2, y - 4, x + 2, y + 4], outline=(*SILVER, 255))
            else:
                d.ellipse([x - 5, y - 3, x + 5, y + 3], outline=(*SILVER, 255), width=2)
    g.part(rect(30, 52 + dy, 98, 108 + dy, 10), R_RED, sigma=6, vgrad=0.15, outline=INK)
    g.part(rect(35, 57 + dy, 93, 103 + dy, 4), [RED, RED, ORANGE], sigma=3, outline=PLUM, gain=0.7)
    d = g.d()
    d.rectangle([32, 100 + dy, 96, 106 + dy], fill=(*PLUM, 255))
    for (x, y) in ((38, 61), (89, 61), (38, 98), (89, 98)):
        g.px(x, y + dy, WHITE); g.px(x + 1, y + dy, SILVER)
    d.rectangle([37, 62 + dy, 91, 77 + dy], fill=(*INK, 255))
    nar = 1 if f == 3 else 0
    for sgn in (0, 1):
        pts = [(40, 64), (60, 70), (60, 75), (40, 71)] if sgn == 0 else [(88, 64), (68, 70), (68, 75), (88, 71)]
        d.polygon([(x, y + dy + nar) for x, y in pts], fill=(*YELLOW, 255))
        d.rectangle([(52 if sgn == 0 else 72), 69 + dy + nar, (55 if sgn == 0 else 75), 73 + dy + nar], fill=(*INK, 255))
    d.ellipse([54, 82 + dy, 74, 100 + dy], fill=(*INK, 255))
    d.polygon([(60, 96 + dy), (68, 96 + dy), (73, 108 + dy), (55, 108 + dy)], fill=(*INK, 255))
    for x in (56, 70):
        d.polygon([(x, 85 + dy), (x + 3, 85 + dy), (x + 1, 90 + dy)], fill=(*WHITE, 255))
    g.part(ell(8, 94 + dy, 24, 110 + dy), R_STEEL, sigma=3)
    g.part(rect(106, 70 + dy, 125, 98 + dy), R_WHITE, sigma=3, light=(-0.5, -0.7))
    d = g.d()
    g.bitmap(DOLLAR, 112, 74 + dy, {'#': RED})
    d.line([(110, 88 + dy), (121, 88 + dy)], fill=(*SLATE, 255)); d.line([(110, 91 + dy), (119, 91 + dy)], fill=(*SLATE, 255))
    d.rectangle([112, 68 + dy, 119, 71 + dy], fill=(*YELLOW, 255))
    g.part(ell(104, 94 + dy, 120, 110 + dy), R_STEEL, sigma=3)
    cb = round(ph(f, 1, 0.3) * 2)
    g.part(ell(88, 12 + cb, 108, 32 + cb), R_GOLD, sigma=4)
    g.bitmap(DOLLAR, 95, 18 + cb, {'#': INK})
    return g.finish()


# =============================================================== 4. INSIDER THREAT - The Colleague
def e_insider(f):
    g = Fig()
    p = ph(f)
    dy = 1 if p > 0.3 else 0
    g.part(multi(rect(48, 92, 62, 118, 2), rect(68, 92, 82, 118, 2)), [DARK, SLATE, SILVER], sigma=2.4, gain=0.7)
    g.part(multi(rect(40, 114, 62, 122, 3), rect(66, 114, 88, 122, 3)), [INK, INK, DARK], sigma=1.6)
    g.part(rect(58, 36 + dy, 70, 50 + dy), R_WHITE, sigma=2)
    g.part(rect(44, 46 + dy, 84, 98 + dy, 8), R_BLUE, sigma=6, vgrad=0.1)
    g.part(poly([(50, 47 + dy), (62, 47 + dy), (64, 70 + dy), (54, 82 + dy)]), R_NAVY, sigma=2, outline=NAVY)
    g.part(poly([(78, 47 + dy), (66, 47 + dy), (64, 70 + dy), (74, 82 + dy)]), R_NAVY, sigma=2, outline=NAVY)
    g.part(poly([(58, 47 + dy), (70, 47 + dy), (64, 68 + dy)]), R_WHITE, sigma=2, outline=None)
    g.part(poly([(62, 52 + dy), (66, 52 + dy), (68, 66 + dy), (64, 82 + dy), (60, 66 + dy)]), R_RED, sigma=1.5, outline=None)
    g.part(ell(46, 6 + dy, 82, 40 + dy), [INK, DARK, SLATE], sigma=5)
    g.part(ell(50, 14 + dy, 80, 45 + dy), R_WHITE, sigma=6, light=(-0.6, -0.7))
    g.part(thick_line([(48, 54 + dy), (40, 68 + dy), (36, 80 + dy)], 11), R_BLUE, sigma=2.4)
    g.part(thick_line([(80, 54 + dy), (92, 70 + dy), (96, 84 + dy)], 11), R_BLUE, sigma=2.4)
    cx = 64
    g.lut({WHITE: ORANGE, SILVER: RED, SLATE: PLUM, SKY: RED, BLUE: PLUM, NAVY: INK, DARK: INK}, XX >= cx)
    d = g.d()
    d.line([(60, 46 + dy), (62, 64 + dy)], fill=(*CYAN, 255)); d.line([(68, 46 + dy), (66, 64 + dy)], fill=(*INK, 255))
    s = round(ph(f, 1, 0.2) * 1.2)
    d.rectangle([59 + s, 64 + dy, 69 + s, 80 + dy], fill=(*WHITE, 255), outline=(*INK, 255))
    d.rectangle([61 + s, 66 + dy, 67 + s, 71 + dy], fill=(*SKY, 255))
    d.line([(61 + s, 75 + dy), (67 + s, 75 + dy)], fill=(*SLATE, 255))
    d.rectangle([56, 25 + dy, 59, 30 + dy], fill=(*INK, 255)); d.point((57, 26 + dy), fill=(*WHITE, 255))
    for x in range(53, 63):
        g.px(x, 36 + dy + round(2.2 * math.sin(math.pi * (x - 53) / 9)), INK)
    g.px(52, 35 + dy, INK)
    d.polygon([(66, 24 + dy), (77, 27 + dy), (76, 32 + dy), (66, 30 + dy)], fill=(*(YELLOW if f != 3 else ORANGE), 255))
    d.rectangle([70, 26 + dy, 72, 30 + dy], fill=(*INK, 255))
    d.line([(65, 22 + dy), (78, 25 + dy)], fill=(*INK, 255), width=2)
    d.line([(66, 38 + dy), (78, 38 + dy)], fill=(*INK, 255))
    for x in (68, 73):
        d.polygon([(x, 38 + dy), (x + 3, 38 + dy), (x + 1, 42 + dy)], fill=(*WHITE, 255))
    g.part(ell(31, 76 + dy, 43, 88 + dy), R_WHITE, sigma=2.5)
    g.part(ell(91, 80 + dy, 103, 92 + dy), R_HOT, sigma=2.5)
    ms = round(ph(f, 1, 0.1))
    g.part(multi(rect(14, 70 + dy + ms, 30, 90 + dy + ms, 2), lambda d: d.arc([26, 74 + dy + ms, 38, 86 + dy + ms], 270, 90, fill=255, width=3)), R_WHITE, sigma=3)
    d = g.d()
    d.rectangle([16, 74 + dy + ms, 28, 76 + dy + ms], fill=(*INK, 255))
    for i, x in enumerate((18, 22, 26)):
        yy = 66 + dy + ms - ((f + i * 2) % 4) * 2
        g.px(x + ((f + i) % 2), yy, SILVER)
    g.part(rect(96, 62 + dy, 106, 82 + dy), R_RED, sigma=2, light=(-0.9, -0.3))
    g.part(rect(98, 50 + dy, 104, 62 + dy), R_STEEL, sigma=1.2)
    g.part(ell(93, 80 + dy, 106, 92 + dy), R_HOT, sigma=2.5)
    d = g.d()
    d.rectangle([99, 52 + dy, 100, 54 + dy], fill=(*INK, 255)); d.rectangle([102, 52 + dy, 103, 54 + dy], fill=(*INK, 255))
    if f % 2 == 0:
        for (x, y) in ((92, 56), (110, 60), (101, 44)):
            g.px(x, y + dy, YELLOW)
    rng = random.Random(f * 7 + 1)
    for i in range(10):
        y = 10 + rng.randrange(0, 105)
        x = 62 + rng.randrange(0, 5)
        g.px(x, y, rng.choice([CYAN, YELLOW, WHITE])); g.px(x + 1, y, rng.choice([CYAN, YELLOW]))
    return g.finish()


# =============================================================== 5. DATA EXFILTRATION - Data Thief
def cube(g, cx, cy, s, f=0):
    h = s // 2
    g.part(poly([(cx - h, cy - h // 2), (cx, cy - h - h // 2), (cx + h, cy - h // 2), (cx, cy + 0)]), R_ICE, sigma=1.5, outline=INK)
    g.part(poly([(cx - h, cy - h // 2), (cx, cy), (cx, cy + h + h // 2), (cx - h, cy + h)]), R_BLUE, sigma=1.8, outline=INK)
    g.part(poly([(cx + h, cy - h // 2), (cx, cy), (cx, cy + h + h // 2), (cx + h, cy + h)]), R_NAVY, sigma=1.8, outline=INK)
    for (x, y) in ((cx - h + 3, cy + 2), (cx - h + 6, cy + 2), (cx - 4, cy + 5), (cx - h + 3, cy + 7)):
        g.px(x, y, WHITE)


def e_exfil(f):
    g = Fig()
    hov = round(ph(f) * 2)
    cx = 64
    by = 66 + hov
    spec = [(-22, -50, 108, 0.0), (-12, -34, 120, 0.3), (-4, -14, 122, 0.6), (4, 14, 122, 0.9), (12, 34, 120, 1.2), (22, 50, 108, 1.5)]
    holds = {0: (cx - 52, 86 + hov), 5: (cx + 52, 80 + hov)}
    for i, (ox, tx, ty, off) in enumerate(spec):
        if i in holds:
            ex, ey = holds[i]
        else:
            ex, ey = cx + tx, ty
        pts = []
        for k in range(14):
            t = k / 13.0
            wav = math.sin(2 * math.pi * (t * 1.2 - f / N + off)) * 5 * t
            x = cx + ox + (ex - cx - ox) * (t ** 0.8) + wav * (1 if i in holds else 0.5)
            y = by + (ey - by) * t
            pts.append((x, y))
        for k in range(len(pts) - 1):
            r = 3.5 - 1.5 * k / 13
            g.part(thick_line([pts[k], pts[k + 1]], max(3, round(r * 2))), R_STEEL, sigma=1.4, outline=None)
        g.part(thick_line(pts, 6), R_STEEL, sigma=1.5, outline=INK) if False else None
        ex_, ey_ = pts[-1]
        g.part(rect(round(ex_) - 3, round(ey_) - 1, round(ex_) + 3, round(ey_) + 3), R_GOLD, sigma=1.0)
    cube(g, cx - 52, 74 + hov, 22)
    cube(g, cx + 52, 68 + hov, 18)
    g.part(rect(42, 62 + hov, 86, 76 + hov, 4), R_DARK, sigma=2)
    g.part(multi(rect(26, 36 + hov, 36, 56 + hov, 3), rect(92, 36 + hov, 102, 56 + hov, 3)), R_DARK, sigma=1.6)
    g.part(ell(34, 12 + hov, 94, 74 + hov), R_STEEL, sigma=10, light=(-0.55, -0.8))
    g.part(rect(40, 30 + hov, 88, 58 + hov, 8), [INK, INK, DARK], sigma=3, outline=SLATE)
    d = g.d()
    ex0 = 46 + round((ph(f, 1, 0.0) + 1) / 2 * 28)
    d.rectangle([ex0, 36 + hov, ex0 + 9, 52 + hov], fill=(*CYAN, 255))
    d.rectangle([ex0 + 2, 38 + hov, ex0 + 4, 41 + hov], fill=(*WHITE, 255))
    for y in range(34 + hov, 56 + hov, 4):
        d.line([(43, y), (85, y)], fill=(*NAVY, 255))
    d.rectangle([ex0, 36 + hov, ex0 + 9, 52 + hov], fill=(*CYAN, 255))
    d.rectangle([ex0 + 2, 38 + hov, ex0 + 4, 41 + hov], fill=(*WHITE, 255))
    d.line([(64, 14 + hov), (64, 4 + hov)], fill=(*SLATE, 255), width=2)
    d.ellipse([60, 0 + hov, 68, 6 + hov], fill=(*(CYAN if f % 2 == 0 else TEAL), 255))
    for j in range(3):
        t = ((f + j * 2) % N) / N
        d.rectangle([cx - 52 + 8 + round(t * 6), round(64 + hov - t * 40), cx - 52 + 11 + round(t * 6), round(67 + hov - t * 40)], fill=(*(CYAN if j != 1 else WHITE), 255))
        d.rectangle([cx + 52 - 4 - round(t * 6), round(56 + hov - t * 40), cx + 52 - 1 - round(t * 6), round(59 + hov - t * 40)], fill=(*(CYAN if j != 2 else WHITE), 255))
    return g.finish()


# =============================================================== 6. DDoS - The Swarm
def bot(g, cx, yb, w, h, f, ph0, boss=False):
    dy = round(ph(f, 1, ph0))
    yb += dy
    g.part(multi(rect(cx - w // 2 + 4, yb - 7, cx - w // 2 + 10, yb), rect(cx + w // 2 - 10, yb - 7, cx + w // 2 - 4, yb)), R_DARK, sigma=1.2)
    y0, y1, x0, x1 = yb - 6 - h, yb - 6, cx - w // 2, cx + w // 2
    g.part(rect(x0, y0, x1, y1, 3), R_STEEL, sigma=3.5)
    g.part(rect(x0 + 3, y0 + 3, x1 - 3, y1 - 5, 2), R_RED if boss else [RED, ORANGE, YELLOW], sigma=4, outline=INK, gain=0.6)
    d = g.d()
    ew = 8 if boss else 5
    eh = 5 if boss else 3
    blink = (f + int(ph0 * 10)) % N == 0
    ey = y0 + (h // 3)
    for sgn in (-1, 1):
        ecx = cx + sgn * (w // 4)
        if blink:
            d.line([(ecx - ew // 2, ey + 1), (ecx + ew // 2, ey + 1)], fill=(*INK, 255))
        else:
            d.rectangle([ecx - ew // 2, ey, ecx + ew // 2, ey + eh], fill=(*WHITE, 255))
            d.rectangle([ecx - 1 + (-1), ey + 1, ecx + (0), ey + eh - 1], fill=(*INK, 255))
        d.line([(ecx - sgn * ew // 2 - sgn * 1, ey - 3 + (0 if sgn < 0 else 0)), (ecx + sgn * -(-ew // 2) * 0 - sgn * (-2), ey - 1)], fill=(*INK, 255))
    my = y1 - 9 if not boss else y1 - 11
    d.rectangle([cx - w // 4, my, cx + w // 4, my + (4 if not boss else 6)], fill=(*INK, 255))
    for x in range(cx - w // 4, cx + w // 4, 3):
        d.point((x, my), fill=(*WHITE, 255))
    return dy


def e_ddos(f):
    g = Fig()
    bots = [(30, 122, 30, 26, 0.0), (64, 122, 30, 26, 0.3), (98, 122, 30, 26, 0.6),
            (47, 92, 30, 24, 0.5), (81, 92, 30, 24, 0.8)]
    d = g.d()
    links = [((30, 100), (64, 40)), ((64, 100), (64, 40)), ((98, 100), (64, 40)), ((47, 74), (64, 40)), ((81, 74), (64, 40))]
    for i, ((x0, y0), (x1, y1)) in enumerate(links):
        d.line([(x0, y0), (x1, y1)], fill=(*TEAL, 255))
        t = ((f + i * 1.2) % N) / N
        d.rectangle([round(x0 + (x1 - x0) * t) - 1, round(y0 + (y1 - y0) * t) - 1, round(x0 + (x1 - x0) * t) + 1, round(y0 + (y1 - y0) * t) + 1], fill=(*YELLOW, 255))
    for (cx, yb, w, h, p0) in bots:
        bot(g, cx, yb, w, h, f, p0)
    g.part(thick_line([(52, 30), (46, 14)], 3), R_STEEL, sigma=1.0)
    g.part(thick_line([(76, 30), (82, 14)], 3), R_STEEL, sigma=1.0)
    d = g.d()
    d.ellipse([43, 9, 49, 15], fill=(*(RED if f % 2 == 0 else ORANGE), 255))
    d.ellipse([79, 9, 85, 15], fill=(*(ORANGE if f % 2 == 0 else RED), 255))
    bot(g, 64, 66, 42, 30, f, 0.15, boss=True)
    g.part(poly([(48, 33), (52, 22), (58, 30), (64, 18), (70, 30), (76, 22), (80, 33)]), R_GOLD, sigma=1.6)
    return g.finish()


# =============================================================== 7. PHISHING - Angler
def e_phish(f):
    g = Fig()
    b = ph(f)
    dy = round(b * 2) - 4
    ta = round(ph(f, 1, 0.1) * 7)
    jaw = [0, 1, 3, 4, 3, 1][f]
    g.part(poly([(98, 78 + dy), (126, 44 + dy + ta), (116, 80 + dy), (126, 112 + dy - ta), (98, 92 + dy)]), R_BLUE, sigma=3.5)
    g.part(poly([(52, 52 + dy), (62, 28 + dy - round(b * 2)), (72, 44 + dy), (84, 24 + dy - round(b * 2)), (96, 56 + dy)]), R_BLUE, sigma=3)
    body = g.mask(ell(20, 46 + dy, 112, 108 + dy))
    g.part(body, R_BLUE, sigma=12, light=(-0.4, -0.9))
    belly = body & (YY >= 80 + dy)
    g.part(belly, [SKY, CYAN, WHITE], sigma=5, outline=None, gain=0.6, light=(-0.2, -0.9))
    d = g.d()
    for (x, y) in ((70, 56), (82, 62), (94, 68), (76, 72), (88, 78), (100, 80), (62, 66)):
        d.arc([x - 5, y - 3 + dy, x + 5, y + 5 + dy], 190, 350, fill=(*NAVY, 255))
    g.part(poly([(62, 82 + dy), (86, 80 + dy), (90, 92 + dy), (78, 102 + dy + round(b)), (66, 98 + dy)]), [BLUE, SKY, CYAN], sigma=2.5)
    d = g.d()
    d.polygon([(20, 68 + dy), (56, 74 + dy), (56, 90 + dy), (22, 98 + dy + jaw)], fill=(*INK, 255))
    d.ellipse([30, 82 + dy + jaw // 2, 48, 96 + dy + jaw], fill=(*RED, 255))
    for i in range(6):
        x = 23 + i * 5
        y = 68 + dy + int(i * 1.0)
        d.polygon([(x, y), (x + 4, y + 1), (x + 2, y + 7)], fill=(*WHITE, 255))
    for i in range(5):
        x = 25 + i * 6
        y = 96 + dy + jaw - int(i * 1.2)
        d.polygon([(x, y), (x + 4, y - 1), (x + 2, y - 7)], fill=(*WHITE, 255))
    d.ellipse([56, 52 + dy, 76, 72 + dy], fill=(*WHITE, 255), outline=(*INK, 255))
    d.ellipse([57 + (-1 if f in (2, 3) else 0), 55 + dy, 67, 68 + dy], fill=(*YELLOW, 255))
    d.rectangle([58 + (-1 if f in (2, 3) else 0), 58 + dy, 63, 64 + dy], fill=(*INK, 255))
    d.polygon([(52, 52 + dy), (78, 58 + dy), (78, 61 + dy), (52, 57 + dy)], fill=(*INK, 255))
    bb = round(ph(f, 1, 0.3) * 2)
    g.part(thick_line([(62, 48 + dy), (56, 28 + dy), (40, 16 + dy), (22, 20 + dy + bb)], 3), R_STEEL, sigma=1.0)
    ex, ey = 6, 34 + dy + bb
    d = g.d()
    for (xx, yy) in ((ex - 4, ey - 4), (ex + 30, ey - 4), (ex - 4, ey + 20), (ex + 30, ey + 20), (ex + 13, ey - 8)):
        if (xx + yy + f) % 2 == 0:
            g.bitmap(['.#.', '###', '.#.'], xx, yy, {'#': YELLOW})
    g.part(rect(ex, ey, ex + 26, ey + 18), R_WHITE, sigma=3, light=(-0.5, -0.8))
    d = g.d()
    d.line([(ex, ey), (ex + 13, ey + 10), (ex + 26, ey)], fill=(*SLATE, 255))
    d.line([(ex, ey + 18), (ex + 10, ey + 9)], fill=(*SILVER, 255)); d.line([(ex + 26, ey + 18), (ex + 16, ey + 9)], fill=(*SILVER, 255))
    g.part(ell(ex + 10, ey + 6, ex + 16, ey + 12), R_RED, sigma=1.5)
    for i, (x, y) in enumerate(((10, 76), (6, 62), (14, 52))):
        yy = y - ((f * 2 + i * 3) % 12)
        d = g.d()
        d.ellipse([x - 2, yy - 2, x + 2, yy + 2], outline=(*CYAN, 255))
    return g.finish()


# =============================================================== 8. WEB APPLICATION ATTACK - Webcrawler
def e_web(f):
    g = Fig()
    p = ph(f)
    dy = 1 if p > 0.3 else 0
    for i in range(4):
        for sgn in (-1, 1):
            hx = 32 if sgn < 0 else 96
            hy = 38 + i * 9 + dy
            kx = hx + sgn * (20, 24, 24, 18)[i]
            ky = (12, 22, 34, 46)[i]
            lift = 5 if (i + f + (1 if sgn > 0 else 0)) % 2 else 0
            fx = (hx + sgn * (28, 22, 15, 8)[i]) + sgn * (3 if lift else 0)
            pts = [(hx, hy), (kx, ky + dy), (fx, 121 - lift)]
            g.part(thick_line(pts, 5), R_STEEL, sigma=1.6, outline=INK)
            g.part(ell(kx - 4, ky - 4 + dy, kx + 4, ky + 4 + dy), R_STEEL, sigma=1.6)
            g.part(ell(fx - 3, 119 - lift, fx + 3, 123 - lift), R_DARK, sigma=1.0)
    g.part(multi(poly([(46, 74 + dy), (54, 74 + dy), (50, 92 + dy + (1 if f % 3 == 0 else 0))]), poly([(74, 74 + dy), (82, 74 + dy), (78, 92 + dy + (1 if f % 3 == 1 else 0))])), R_WHITE, sigma=1.4)
    g.part(rect(32, 22 + dy, 96, 78 + dy, 3), R_STEEL, sigma=6, vgrad=0.05)
    g.part(rect(35, 25 + dy, 93, 36 + dy), R_DARK, sigma=2, outline=None)
    d = g.d()
    for x, c in ((38, RED), (45, YELLOW), (52, GREEN)):
        d.ellipse([x, 28 + dy, x + 4, 32 + dy], fill=(*c, 255))
    d.rectangle([60, 28 + dy, 90, 33 + dy], fill=(*INK, 255))
    d.line([(62, 30 + dy), (78, 30 + dy)], fill=(*CYAN, 255))
    g.part(rect(35, 38 + dy, 93, 75 + dy), [INK, INK, DARK], sigma=3, outline=SLATE, gain=0.5)
    d = g.d()
    for y in range(40 + dy, 74 + dy, 4):
        d.line([(37, y), (91, y)], fill=(*NAVY, 255))
    for sgn in (0, 1):
        pts = [(40, 46), (59, 52), (59, 58), (40, 52)] if sgn == 0 else [(88, 46), (69, 52), (69, 58), (88, 52)]
        if f == 3:
            d.line([(pts[0][0], 54 + dy), (pts[1][0], 55 + dy)], fill=(*LIME, 255))
        else:
            d.polygon([(x, y + dy) for x, y in pts], fill=(*LIME, 255))
            d.point((pts[1][0] - (3 if sgn == 0 else -3), 54 + dy), fill=(*WHITE, 255))
    g.bitmap(['..#.#.....#.#.', '.#..#.....#..#', '#...#.###.#...', '.#..#.....#..#', '..#.#.....#.#.'][0:0] or [], 0, 0, {})
    code = ['..#...........#..', '.#.....#.#....#.', '#......#.#.....#', '.#.....#.#....#.', '..#...........#..']
    d.line([(46, 68 + dy), (82, 68 + dy)], fill=(*TEAL, 255))
    for i in range(10):
        x = 48 + i * 3
        d.polygon([(x, 66 + dy), (x + 3, 66 + dy), (x + 1, 69 + dy)], fill=(*(WHITE if i % 3 else LIME), 255))
    if f in (0, 1, 2):
        d.rectangle([86, 62 + dy, 89, 70 + dy], fill=(*LIME, 255))
    d.line([(38, 41 + dy), (46, 41 + dy)], fill=(*GREEN, 255)); d.line([(38, 71 + dy), (50, 71 + dy)], fill=(*GREEN, 255))
    return g.finish()


ENEMIES = [
    ('credential_abuse', 'Credential Abuse', 'The Impersonator', e_credential),
    ('malware', 'Malware', 'Glitch Bug', e_malware),
    ('ransomware', 'Ransomware', 'Lockjaw', e_ransom),
    ('insider_threat', 'Insider Threat', 'The Colleague', e_insider),
    ('data_exfiltration', 'Data Exfiltration', 'Data Thief', e_exfil),
    ('ddos', 'DDoS', 'The Swarm', e_ddos),
    ('phishing', 'Phishing', 'Angler', e_phish),
    ('web_app_attack', 'Web Application Attack', 'Webcrawler', e_web),
]

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'enemies2_out'
    only = sys.argv[2].split(',') if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for slug, threat, nick, fn in ENEMIES:
        if only and slug not in only:
            continue
        frs = [fn(f) for f in range(N)]
        for i, fr in enumerate(frs):
            check_palette(fr, f'{slug}{i}')
        sheet = Image.new('RGBA', (S * N, S), (0, 0, 0, 0))
        for i, fr in enumerate(frs):
            sheet.alpha_composite(fr, (i * S, 0))
        sheet.save(os.path.join(out, f'{slug}_idle_sheet.png'))
        pv = Image.new('RGBA', (S * 3 + 8, S * 2 + 6), (*INK, 255))
        for i, fr in enumerate(frs):
            pv.alpha_composite(fr, (2 + (i % 3) * (S + 2), 2 + (i // 3) * (S + 2)))
        pv.resize((pv.width * 2, pv.height * 2), Image.NEAREST).save(os.path.join(out, f'{slug}_preview.png'))
    print('ok')
