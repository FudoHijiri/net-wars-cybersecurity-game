"""Hardening shop background - simple 'blueprint' room, same family as the Response grid. Sweetie 16 only, 640x360, binary alpha.
Hardening = designing defenses, so the field is blueprint paper: NAVY base, dotted BLUE 40 px grid with + marks at the crossings (same 40 px cell as the
Response grid), two faint doodles (shield, padlock) near the top corners, and an INK dither vignette that keeps the centre calm for the deck + shop UI."""
import os, sys
import numpy as np
from PIL import Image, ImageDraw

INK, NAVY, BLUE, SKY = (26, 28, 44), (41, 54, 111), (59, 93, 201), (65, 166, 246)
PALETTE = {INK, NAVY, BLUE, SKY}
W, H, T = 640, 360, 40
out = sys.argv[1] if len(sys.argv) > 1 else 'hard_out'
os.makedirs(out, exist_ok=True)
b = np.array([[0, 32, 8, 40, 2, 34, 10, 42], [48, 16, 56, 24, 50, 18, 58, 26], [12, 44, 4, 36, 14, 46, 6, 38], [60, 28, 52, 20, 62, 30, 54, 22],
              [3, 35, 11, 43, 1, 33, 9, 41], [51, 19, 59, 27, 49, 17, 57, 25], [15, 47, 7, 39, 13, 45, 5, 37], [63, 31, 55, 23, 61, 29, 53, 21]]) / 64.0
BAY = np.tile(b, (H // 8 + 1, W // 8 + 1))[:H, :W]
smooth = lambda x, a, c: (lambda t: t * t * (3 - 2 * t))(np.clip((x - a) / (c - a), 0, 1))

im = Image.new('RGBA', (W, H), (*NAVY, 255))
a = np.array(im)
yy, xx = np.mgrid[0:H, 0:W]
# dotted grid lines every 40 px (checker dots) + solid '+' marks at crossings
lines = ((xx % T == 0) | (yy % T == 0)) & ((xx + yy) % 2 == 0)
a[lines] = (*BLUE, 255)
for gy in range(0, H + 1, T):
    for gx in range(0, W + 1, T):
        for dx, dy in ((0, 0), (-1, 0), (1, 0), (0, -1), (0, 1), (-2, 0), (2, 0), (0, -2), (0, 2)):
            x, y = gx + dx, gy + dy
            if 0 <= x < W and 0 <= y < H:
                a[y, x] = (*BLUE, 255)
im = Image.fromarray(a)
# vignette: INK dither toward the edges, strongest at the corners
dist = np.hypot((xx - W / 2) / (W / 2), (yy - H / 2) / (H / 2)) / 1.2
p = smooth(dist, 0.72, 1.18) * 0.9
a[BAY < p] = (*INK, 255)
im = Image.fromarray(a)
d = ImageDraw.Draw(im)
# doodles: shield (top-left) and padlock (top-right), 1 px BLUE outlines
sx, sy = 52, 40
d.polygon([(sx - 11, sy - 13), (sx + 11, sy - 13), (sx + 11, sy + 2), (sx, sy + 14), (sx - 11, sy + 2)], outline=(*SKY, 255))
d.line([(sx, sy - 8), (sx, sy + 6)], fill=(*SKY, 255)); d.line([(sx - 6, sy - 3), (sx + 6, sy - 3)], fill=(*SKY, 255))
lx, ly = 590, 40
d.rectangle([lx - 9, ly - 3, lx + 9, ly + 12], outline=(*SKY, 255))
d.arc([lx - 6, ly - 13, lx + 6, ly + 1], 180, 360, fill=(*SKY, 255)); d.line([(lx - 6, ly - 7), (lx - 6, ly - 3)], fill=(*SKY, 255)); d.line([(lx + 6, ly - 7), (lx + 6, ly - 3)], fill=(*SKY, 255))
d.rectangle([lx - 1, ly + 2, lx + 1, ly + 6], fill=(*SKY, 255))
# corner registration marks
for cx, cy, sxn, syn in ((8, 8, 1, 1), (W - 9, 8, -1, 1), (8, H - 9, 1, -1), (W - 9, H - 9, -1, -1)):
    d.line([(cx, cy), (cx + 12 * sxn, cy)], fill=(*SKY, 255)); d.line([(cx, cy), (cx, cy + 12 * syn)], fill=(*SKY, 255))
a = np.array(im)
Image.fromarray(a).save(f'{out}/hardening_bg_640x360.png')
cols = {tuple(c[:3]) for c in a.reshape(-1, 4) if c[3]}
assert cols <= PALETTE, cols - PALETTE
print('ok')
