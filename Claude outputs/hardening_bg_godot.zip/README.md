# Hardening shop background
Blueprint paper: NAVY base, dotted 40 px BLUE grid with + marks (same 40 px cell as the Response grid), a shield and padlock doodle in the top corners,
corner registration marks, and an INK dither vignette that keeps the centre calm for the deck and shop UI. Palette: INK, NAVY, BLUE, SKY. 640x360, binary alpha.
Static single image (no animation). Not tested in Godot. Rebuild: python3 tools/make_hardening_bg.py <outdir>
