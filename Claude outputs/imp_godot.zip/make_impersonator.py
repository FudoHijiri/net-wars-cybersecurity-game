"""Credential Abuse enemy v3 - 'The Impersonator'. 128x128, 6-frame idle, Sweetie 16 only, faces LEFT, ground row 122.
Visual system (see art-direction brief):
  shape   : threat = tall tapered triangle, sharp shoulders, pointed hood; hero = round/chunky
  focal   : (1) white stolen-ID mask  (2) glowing yellow eyes  (3) key ring        -> everything else is dark mass
  value   : 4 bands only. coat dark plum, hood plum+red edge, card near-white, eyes/keys yellow
  edge    : 1 px INK outline per part, cel bands (no dither), isolated single pixels removed
"""
import math, os, sys
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fig import *
from make_enemies_v2 import ph, ell, rect, poly, multi, N

STAR = ['..#..', '#.#.#', '.###.', '#.#.#', '..#..']


def despeckle(im):
    a = np.array(im)
    h, w = a.shape[:2]
    out = a.copy()
    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if a[y, x, 3] == 0:
                continue
            c = a[y, x, :3]
            nb = [a[y - 1, x], a[y + 1, x], a[y, x - 1], a[y, x + 1]]
            if all((n[3] == 255 and tuple(n[:3]) != tuple(c)) for n in nb):
                cols = [tuple(n[:3]) for n in nb]
                best = max(set(cols), key=cols.count)
                if cols.count(best) >= 2 and c.tolist() not in ([*YELLOW], [*WHITE]):
                    out[y, x, :3] = best
    return Image.fromarray(out)


def key_shape(g, ox, oy, ang, length, big=False):
    ca, sa = math.cos(ang), math.sin(ang)
    rot = lambda x, y: (ox + x * ca - y * sa, oy + x * sa + y * ca)
    r = 4.5 if big else 3.5
    hx, hy = rot(0, 3)
    shaft = [rot(-1.5, 3), rot(1.5, 3), rot(1.5, length), rot(-1.5, length)]
    t1 = [rot(1.5, length - 7), rot(5, length - 7), rot(5, length - 4), rot(1.5, length - 4)]
    t2 = [rot(1.5, length - 3), rot(4, length - 3), rot(4, length), rot(1.5, length)]
    g.part(lambda d: (d.polygon(shaft, fill=255), d.polygon(t1, fill=255), d.polygon(t2, fill=255), d.ellipse([hx - r, hy - r, hx + r, hy + r], fill=255)), [ORANGE, YELLOW, YELLOW], sigma=0.9, dw=0.0)
    d = g.d()
    d.ellipse([hx - 1.4, hy - 1.4, hx + 1.4, hy + 1.4], fill=(*INK, 255))


def impersonator(f):
    g = Fig()
    dy = [0, 0, 1, 1, 1, 0][f]
    sw = ph(f)
    sw2 = ph(f, 1, 0.3)
    tipf = round(ph(f, 1, 0.1) * 2)
    cd = 1 if f in (2, 3) else 0
    # hood tip (behind)
    g.part(poly([(84, 12 + dy), (104, 24 + tipf + dy), (116, 40 + tipf * 2 + dy), (100, 38 + dy), (86, 44 + dy)]), R_PLUM, sigma=3, dw=0.0)
    # coat
    hem = []
    for i, x in enumerate(range(103, 24, -9)):
        hem.append((x, 122 - (1 if (i + f) % 2 else 0)))
        hem.append((x - 4, 110 + ((i + f + 1) % 2) * 3))
    coat = [(50, 56 + dy), (80, 56 + dy), (83, 70), (82, 86), (92, 104), (103, 122)] + hem + [(24, 122), (34, 104), (46, 86), (46, 70)]
    cm = g.part(poly(coat), R_PLUM, sigma=9, vgrad=0.15, dw=0.0)
    d = g.d()
    for x0, x1 in ((48, 40), (78, 86)):
        d.line([(x0, 92), (x1, 112)], fill=(*INK, 255))
    a_ = np.array(g.im)
    for yy in range(85 + dy, 90 + dy):
        row = cm[yy] if yy < S else None
        a_[yy, row] = (*(SLATE if yy == 85 + dy else DARK), 255)
    g.im.paste(Image.fromarray(a_), (0, 0))
    d = g.d()
    d.rectangle([62, 84 + dy, 70, 90 + dy], fill=(*YELLOW, 255), outline=(*ORANGE, 255))
    # spiked shoulders
    g.part(poly([(84, 58 + dy), (100, 46 + dy), (94, 68 + dy)]), R_PLUM, sigma=2, dw=0.0)
    g.part(poly([(46, 58 + dy), (34, 48 + dy), (42, 68 + dy)]), R_PLUM, sigma=2, dw=0.0)
    # back arm + fan of stolen ID cards
    g.part(thick_line([(80, 62 + dy), (88, 74 + dy), (94, 86 + dy)], 11), R_PLUM, sigma=3, dw=0.0)
    px_, py_ = 95, 90 + dy
    spread = 0.05 * ph(f, 1, 0.25)
    for ci, (a0, ramp, photo) in enumerate(((-0.62, [BLUE, SKY, CYAN], SLATE), (-0.08, [ORANGE, YELLOW, YELLOW], RED), (0.46, [SILVER, WHITE, WHITE], SLATE))):
        an = a0 + spread * (ci - 1) * 2
        ca, sa = math.cos(an), math.sin(an)
        rot = lambda x, y, ca=ca, sa=sa: (px_ + x * ca - y * sa, py_ + x * sa + y * ca)
        quad = [rot(-8, 3), rot(8, 3), rot(8, -26), rot(-8, -26)]
        ph_ = [rot(-5, -8), rot(1, -8), rot(1, -20), rot(-5, -20)]
        g.part(poly(quad), ramp, sigma=2.0, dw=0.0)
        g.part(poly(ph_), [photo, photo, photo], sigma=1, outline=None, dw=0.0)
        for yy_ in (-12, -16):
            x0_, y0_ = rot(3, yy_); x1_, y1_ = rot(6, yy_)
            g.d().line([(x0_, y0_), (x1_, y1_)], fill=(*INK, 255))
    g.part(ell(88, 82 + dy, 102, 96 + dy), R_DARK, sigma=2.5, dw=0.0)
    # front arm (mostly behind the card)
    g.part(thick_line([(52, 60 + dy), (42, 72 + dy), (34, 84 + dy)], 12), R_PLUM, sigma=3, dw=0.0)
    # hood
    hood = [(40, 46 + dy), (42, 24 + dy), (54, 9 + dy), (70, 4 + dy), (86, 10 + dy), (92, 24 + dy), (90, 38 + dy), (84, 52 + dy), (62, 58 + dy), (46, 54 + dy)]
    g.part(poly(hood), R_PLUM, sigma=7, light=(-0.6, -0.8), dw=0.0)
    g.part(poly([(42, 28 + dy), (54, 18 + dy), (70, 18 + dy), (82, 28 + dy), (80, 46 + dy), (62, 54 + dy), (44, 48 + dy)]), [INK, INK, DARK], sigma=3, outline=None, dw=0.0)
    d = g.d()
    pulse = 1 if f in (3, 4) else 0
    for sgn in (0, 1):
        pts = [(46, 28), (60, 33), (60, 38), (47, 34)] if sgn == 0 else [(78, 28), (64, 33), (64, 38), (77, 34)]
        if f == 5:
            d.line([(pts[0][0], 36 + dy), (pts[1][0], 36 + dy)], fill=(*YELLOW, 255))
        else:
            d.polygon([(x, y + dy) for x, y in pts], fill=(*(ORANGE if pulse else YELLOW), 255))
            d.polygon([(x, y + dy + 1) for x, y in pts[1:3]] + [(pts[2][0] - 3, pts[2][1] + dy), (pts[1][0] - 3, pts[1][1] + dy)], fill=(*YELLOW, 255)) if pulse else None
            g.px(pts[1][0] - 2, pts[1][1] + dy + 1, WHITE)
    # stolen ID card used as a mask
    cx0, cy0 = 26, 42 + dy + cd
    g.part(rect(cx0, cy0, cx0 + 32, cy0 + 42, 3), [SILVER, WHITE, WHITE], sigma=3, gain=0.5, vgrad=0.0, dw=0.0)
    d = g.d()
    d.rectangle([cx0 + 2, cy0 + 2, cx0 + 30, cy0 + 9], fill=(*BLUE, 255))
    d.rectangle([cx0 + 4, cy0 + 4, cx0 + 8, cy0 + 7], fill=(*WHITE, 255))
    d.rectangle([cx0 + 11, cy0 + 5, cx0 + 27, cy0 + 6], fill=(*SKY, 255))
    d.rectangle([cx0 + 3, cy0 + 12, cx0 + 15, cy0 + 27], fill=(*SKY, 255))
    d.rectangle([cx0 + 3, cy0 + 12, cx0 + 15, cy0 + 14], fill=(*SLATE, 255))
    for ex in (6, 11):
        d.rectangle([cx0 + ex, cy0 + 19, cx0 + ex + 1, cy0 + 21], fill=(*INK, 255))
    for k, y in enumerate((24, 25, 25, 25, 24)):
        d.point((cx0 + 6 + k, cy0 + y + 1), fill=(*INK, 255))
    for y in (13, 17, 21):
        d.line([(cx0 + 18, cy0 + y), (cx0 + 29, cy0 + y)], fill=(*SLATE, 255))
    d.rectangle([cx0 + 24, cy0 + 24, cx0 + 29, cy0 + 28], fill=(*YELLOW, 255), outline=(*ORANGE, 255))
    d.line([(cx0 + 3, cy0 + 31), (cx0 + 29, cy0 + 31)], fill=(*SLATE, 255))
    d.line([(cx0 + 3, cy0 + 34), (cx0 + 20, cy0 + 34)], fill=(*SLATE, 255))
    for k in range(12):
        x = cx0 + 4 + k * 2
        d.line([(x, cy0 + 37), (x, cy0 + 39)], fill=(*INK, 255))
    # glove holding the card
    g.part(ell(22, 74 + dy + cd, 36, 90 + dy + cd), R_DARK, sigma=2.5, dw=0.0)
    d = g.d()
    d.line([(34, 80 + dy + cd), (34, 84 + dy + cd)], fill=(*SLATE, 255))
    return despeckle(g.finish(outer=RED))


if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'imp_out'
    os.makedirs(out, exist_ok=True)
    frs = [impersonator(f) for f in range(N)]
    for i, fr in enumerate(frs):
        check_palette(fr, f'imp{i}')
    sheet = Image.new('RGBA', (S * N, S), (0, 0, 0, 0))
    for i, fr in enumerate(frs):
        sheet.alpha_composite(fr, (i * S, 0))
    sheet.save(os.path.join(out, 'credential_abuse_idle_sheet.png'))
    pv = Image.new('RGBA', (S * 3 + 8, S * 2 + 6), (*INK, 255))
    for i, fr in enumerate(frs):
        pv.alpha_composite(fr, (2 + (i % 3) * (S + 2), 2 + (i // 3) * (S + 2)))
    pv.resize((pv.width * 2, pv.height * 2), Image.NEAREST).save(os.path.join(out, 'preview.png'))
    print('ok')
