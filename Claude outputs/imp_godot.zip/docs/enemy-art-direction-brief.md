# Enemy art direction brief (seed: Credential Abuse, "The Impersonator")

## Game frame
- Engine/renderer: Godot 4.7, GL Compatibility, 640x360 viewport, integer stretch, nearest filtering
- View: side view, enemy faces LEFT toward the hero, stands on the right platform at (492, 250)
- Asset size: 128x128 per frame, ground row 122, 6-frame idle at 6 fps

## Visual system
- Shape language: hero = round and chunky; threats = tall, tapered, pointed (sharp hood, spiked shoulders, ragged hem)
- Silhouette priorities: (1) stolen-ID mask (2) glowing eyes (3) fan of stolen cards. Nothing small floats off the body.
- Value structure: 4 bands. Dark coat mass, near-white card, yellow eyes. Must read in grayscale against the dark skyline.
- Palette roles (Sweetie 16 only): plum/red = threat body; yellow = eyes and "danger focus"; white/sky = stolen identity; ink = outline
- Edge: 1 px ink outline per part plus a 1 px red rim so the dark body separates from the skyline; cel bands, no dither; single isolated pixels removed
- Light: top-left
- Detail density: concentrated on the card and eyes; the coat is large flat planes
- Motion: restrained. Breathing, hem tatters, hood tip, card float, card fan spread, eye pulse and one blink
- Exclusions: text, labels, floating particles, dithered noise

## Technical contract
- 128x128 frames in a 768x128 sheet, RGBA, transparent background, nearest filtering, no mipmaps
- Anchor: bottom-center, offset Vector2(-64, -122)
- Names: assets/charactersprite/enemies/<threat>_idle_sheet.png, <threat>_frames.tres, scenes/gameplay/response/enemies/<Threat>Enemy.tscn
